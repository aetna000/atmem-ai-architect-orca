# Component and interface contracts

Snapshot a4c8e595-443e-46cc-9fe7-32a01c06b3e9 · design r2 · generated 2026-11-15T09:19:00.853Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component user: Staff browser

- Responsibility: Staff member's browser. This is a client reference, not a provisioned service.
- Service: Approval workflow
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-75736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component web: Web app

- Responsibility: Browser channel (required scope). It owns private S3 assets and CloudFront access control, uses authorization code with PKCE, and shows answers with citations.
- Service: Amazon CloudFront
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-776562
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component cognito: User sign-in

- Responsibility: User pool with admin-created users, required software-token MFA, an access-token scope, and catalog-backed identity and employee-region mapping. Users are onboarded with the operator tool.
- Service: Amazon Cognito
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f676e69746f
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component api: RAG API

- Responsibility: Authenticated, bounded HTTP API with a JWT browser route. There is no anonymous access. Access logs support the audit trail.
- Service: Amazon API Gateway
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617069
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component rag-fn: Keyword RAG function

- Responsibility: Keyword retrieval with ACL and region filtering and revision rechecks, then a cited answer that is returned through the API. It owns its execution role, logs, version and alias. Unknown identities fail closed.
- Service: AWS Lambda
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7261672d666e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

## Component catalog: Document catalog

- Responsibility: Holds up to 100 small UTF-8 documents with explicit ACLs, revisions, tombstones for deletes and a sync checkpoint. Writes are conditional.
- Service: Amazon DynamoDB
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636174616c6f67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
- Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.

## Component model: Foundation model

- Responsibility: Existing Bedrock direct model, selected by a required model-ID input. Model access, Converse support, quotas and regional availability are not yet verified.
- Service: Amazon Bedrock
- Provider / placement: aws / ap-southeast-2
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Component sp-src: SharePoint (test server)

- Responsibility: Existing SharePoint, represented here by the approved local normalized source-contract test server. It provides snapshots, ACLs, updates and deletes. The native API and real-tenant compatibility are not verified.
- Service: Storage or existing data connector
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-73702d737263
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Component cf-src: Confluence (test server)

- Responsibility: Existing Confluence, represented here by the approved local normalized source-contract test server. The native API and real-tenant compatibility are not verified.
- Service: Storage or existing data connector
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-63662d737263
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Interfaces

### e-user-web: user → web

- Drawn payload/purpose: HTTPS
- Contract task: TASK-CONTRACT-652d757365722d776562
- Integration task: TASK-INTEGRATION-652d757365722d776562
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### e-web-cognito: web → cognito

- Drawn payload/purpose: sign-in (PKCE + MFA)
- Contract task: TASK-CONTRACT-652d7765622d636f676e69746f
- Integration task: TASK-INTEGRATION-652d7765622d636f676e69746f
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### e-cognito-api: cognito → api

- Drawn payload/purpose: JWT authorizer
- Contract task: TASK-CONTRACT-652d636f676e69746f2d617069
- Integration task: TASK-INTEGRATION-652d636f676e69746f2d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### e-web-api: web → api

- Drawn payload/purpose: question → cited answer
- Contract task: TASK-CONTRACT-652d7765622d617069
- Integration task: TASK-INTEGRATION-652d7765622d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### e-api-fn: api → rag-fn

- Drawn payload/purpose: invoke
- Contract task: TASK-CONTRACT-652d6170692d666e
- Integration task: TASK-INTEGRATION-652d6170692d666e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### e-fn-catalog: rag-fn → catalog

- Drawn payload/purpose: ACL-filtered keyword read
- Contract task: TASK-CONTRACT-652d666e2d636174616c6f67
- Integration task: TASK-INTEGRATION-652d666e2d636174616c6f67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### e-fn-model: rag-fn → model

- Drawn payload/purpose: Converse (grounded prompt)
- Contract task: TASK-CONTRACT-652d666e2d6d6f64656c
- Integration task: TASK-INTEGRATION-652d666e2d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### e-sp-catalog: sp-src → catalog

- Drawn payload/purpose: snapshot sync, ACLs, deletes
- Contract task: TASK-CONTRACT-652d73702d636174616c6f67
- Integration task: TASK-INTEGRATION-652d73702d636174616c6f67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### e-cf-catalog: cf-src → catalog

- Drawn payload/purpose: snapshot sync, ACLs, deletes
- Contract task: TASK-CONTRACT-652d63662d636174616c6f67
- Integration task: TASK-INTEGRATION-652d63662d636174616c6f67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
