# Implementation Spec Kit

Snapshot a4c8e595-443e-46cc-9fe7-32a01c06b3e9 · design r2 · generated 2026-11-15T09:19:00.853Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

0 priority decisions; infrastructure: generated_implementation_unverified. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Review component engineering work and confirm the implementation scope.

## Intended outcome

Design an AWS knowledge assistant that reads approved documents from existing SharePoint and Confluence systems and provides cited answers through a web application, with Teams as a later channel. Preserve source permissions, updates and deletes. For this stage use the approved local normalized source-contract test servers and bounded keyword retrieval. Keep the requested web application as required scope; an HTTP API alone does not complete that channel. Treat those existing systems as external dependencies; include recovery and audit behavior without claiming native vendor API or real tenant compatibility. Use AWS for this synthetic qualification design. Propose Sydney as a candidate region, but do not record that as an approved deployment region. Draw the architecture and identify the next missing decision. This is a test design, not an instruction to deploy.

## Confirmed design decisions

- platform.cloud: aws
- cloud.region: ap-southeast-2
- data.country: Australia
- model.bedrock: amazon.nova-lite-v1:0
- logs.retention: 30 days

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Staff browser (user): External browser — no infrastructure to provision; connection behavior still requires validation; tools, To be selected.
- Web app (web): Private web hosting and Cognito authorization-code/PKCE sign-in generated; aws, ap-southeast-2.
- User sign-in (cognito): Private web hosting and Cognito authorization-code/PKCE sign-in generated; aws, ap-southeast-2.
- RAG API (api): Bounded IAM-authenticated RAG implementation generated; aws, ap-southeast-2.
- Keyword RAG function (rag-fn): Bounded IAM-authenticated RAG implementation generated; aws, ap-southeast-2.
- Document catalog (catalog): Bounded IAM-authenticated RAG implementation generated; aws, ap-southeast-2.
- Foundation model (model): Bounded IAM-authenticated RAG implementation generated; aws, ap-southeast-2.
- SharePoint (test server) (sp-src): Local source-contract runner generated; native vendor integration unverified; tools, To be selected.
- Confluence (test server) (cf-src): Local source-contract runner generated; native vendor integration unverified; tools, To be selected.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.
